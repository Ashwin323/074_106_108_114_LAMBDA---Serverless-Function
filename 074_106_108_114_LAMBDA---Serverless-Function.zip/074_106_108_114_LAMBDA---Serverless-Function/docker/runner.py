import sys

exec(sys.stdin.read())

